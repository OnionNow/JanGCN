
def load_data(triplefile):
    print('loading entity2id.txt ...')
    with open('entity2id.txt') as f:
        entity2id = {line.strip().split('\t')[0]: int(line.strip().split('\t')[1]) for line in f.readlines()}
        id2entity = {value:key for key,value in entity2id.items()}
        #print(id2entity)
    with open('relation2id.txt') as f:
        relation2id = {line.strip().split('\t')[0]: int(line.strip().split('\t')[1]) for line in f.readlines()}
        id2relation = {value:key for key,value in relation2id.items()}
        #print(id2relation)
    triple_list = [] #[(head_id, relation_id, tail_id),...]
    with open(triplefile) as f:
        for line in f.readlines():
            line_list = line.strip().split('\t')
            assert len(line_list) == 3
            head = id2entity[int(line_list[0])]
            relation = id2relation[int(line_list[2])]
            tail = id2entity[int(line_list[1])]
            with open('test.txt', 'a+', encoding='utf-8') as file1:
                file1.write(head+'\t'+relation+'\t'+tail)
                #f.write(head)
                #f.write('\t')
                #f.write(relation)
                #f.write('\t')
                #f.write(tail)
                file1.write('\n')
            triple_list.append((head, relation, tail))
            #print(triple_list)
    return triple_list
txt = load_data('test2id.txt')
